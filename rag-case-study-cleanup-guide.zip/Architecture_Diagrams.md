# RAG Architecture Diagrams
**Ready to use in README or convert to images**

---

## Diagram 1: Simple Flow (For README)

### ASCII Diagram

```
┌─────────────────────────────────────────────────────────┐
│                    User Query                            │
└─────────────────────┬───────────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────────┐
│              Query Embedding Generation                  │
│         (sentence-transformers/all-mpnet-base-v2)       │
└─────────────────────┬───────────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────────┐
│            Cosine Similarity Search                      │
│              (In-Memory Vector Store)                    │
│                  chunks.json (50)                        │
│               embeddings.pkl (768-dim)                   │
└─────────────────────┬───────────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────────┐
│               Top-K Retrieval (K=3)                      │
│            Most Relevant Document Chunks                 │
└─────────────────────┬───────────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────────┐
│              Context-Grounded Generation                 │
│  ┌─────────────┬─────────────┬─────────────┐           │
│  │   Claude    │   Gemini    │   OpenAI    │           │
│  │  Sonnet 4   │ 2.0 Flash   │   GPT-4o    │           │
│  └─────────────┴─────────────┴─────────────┘           │
└─────────────────────┬───────────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────────┐
│                  Final Answer                            │
│            (Grounded in Retrieved Context)               │
└─────────────────────────────────────────────────────────┘
```

---

## Diagram 2: Mermaid Flowchart

### For GitHub README (Native Rendering)

````markdown
```mermaid
flowchart TD
    A[User Query] --> B[Query Embedding Generation]
    B --> C{Cosine Similarity Search}
    C --> D[Top-K Retrieval K=3]
    D --> E{Multi-LLM Generation}
    
    E --> F1[Claude<br/>Sonnet 4]
    E --> F2[Gemini<br/>2.0 Flash]
    E --> F3[OpenAI<br/>GPT-4o]
    
    F1 --> G[Final Answer]
    F2 --> G
    F3 --> G
    
    H[(chunks.json<br/>50 chunks)] -.-> C
    I[(embeddings.pkl<br/>768-dim)] -.-> C
    
    style A fill:#e1f5ff
    style G fill:#e8f5e9
    style C fill:#fff3e0
    style E fill:#f3e5f5
```
````

---

## Diagram 3: Detailed Architecture (Mermaid)

````markdown
```mermaid
graph TB
    subgraph "1. Document Processing"
        PDF[Apple Case Study PDF] --> CHUNK[Chunking Pipeline<br/>500 tokens, 50 overlap]
        CHUNK --> STORE1[(chunks.json<br/>~50 chunks)]
    end
    
    subgraph "2. Embedding Generation"
        STORE1 --> EMB[Sentence Transformer<br/>all-mpnet-base-v2]
        EMB --> STORE2[(embeddings.pkl<br/>768-dimensional)]
    end
    
    subgraph "3. Query Processing"
        QUERY[User Query] --> QEMB[Query Embedding<br/>same model]
    end
    
    subgraph "4. Retrieval"
        QEMB --> SIM[Cosine Similarity<br/>Search]
        STORE2 -.-> SIM
        SIM --> TOPK[Top-3 Chunks]
    end
    
    subgraph "5. Generation"
        TOPK --> PROMPT[Context + Query<br/>Prompt Construction]
        PROMPT --> LLM{Multi-LLM<br/>Selection}
        LLM --> CLAUDE[Claude 3.5<br/>Sonnet]
        LLM --> GEMINI[Gemini 2.0<br/>Flash]
        LLM --> GPT[GPT-4o]
    end
    
    subgraph "6. Response"
        CLAUDE --> ANS[Final Answer]
        GEMINI --> ANS
        GPT --> ANS
    end
    
    style PDF fill:#bbdefb
    style QUERY fill:#bbdefb
    style ANS fill:#c8e6c9
    style SIM fill:#fff9c4
```
````

---

## Diagram 4: System Components (Mermaid)

````markdown
```mermaid
graph LR
    subgraph "Frontend"
        UI[Streamlit Interface]
    end
    
    subgraph "RAG Core"
        RAG[rag_system.py]
        MULTI[rag_system_multimodel.py]
    end
    
    subgraph "Storage"
        CHUNKS[(chunks.json)]
        EMB[(embeddings.pkl)]
    end
    
    subgraph "LLM Providers"
        C[Claude API]
        G[Gemini API]
        O[OpenAI API]
    end
    
    UI --> RAG
    RAG --> MULTI
    RAG --> CHUNKS
    RAG --> EMB
    MULTI --> C
    MULTI --> G
    MULTI --> O
    
    style UI fill:#e1f5ff
    style RAG fill:#fff3e0
    style MULTI fill:#f3e5f5
```
````

---

## How to Use These Diagrams

### Option 1: Use in README (GitHub Native)

GitHub renders Mermaid natively. Just paste the code:

````markdown
## Architecture

```mermaid
flowchart TD
    A[User Query] --> B[Embedding]
    B --> C[Search]
    C --> D[Generate]
```
````

### Option 2: Convert to PNG (For Portfolio)

**Using Mermaid Live Editor:**

1. Go to https://mermaid.live/
2. Paste the Mermaid code
3. Click "Download PNG"
4. Save to `assets/architecture.png`

**Using Command Line:**

```bash
# Install mermaid-cli
npm install -g @mermaid-js/mermaid-cli

# Convert to PNG
mmdc -i diagram.mmd -o architecture.png -w 1200 -H 800
```

### Option 3: Use Excalidraw (Hand-drawn Style)

Open https://excalidraw.com/ and create:

```
┌────────────────────────────────────┐
│                                    │
│         User Query                 │
│                                    │
└─────────────┬──────────────────────┘
              │
              ↓
┌────────────────────────────────────┐
│                                    │
│    Generate Query Embedding        │
│   (sentence-transformers)          │
│                                    │
└─────────────┬──────────────────────┘
              │
              ↓
┌────────────────────────────────────┐
│                                    │
│   Search In-Memory Vector Store    │
│                                    │
│   ┌──────────┐  ┌──────────┐      │
│   │ chunks   │  │embeddings│      │
│   │  .json   │  │   .pkl   │      │
│   └──────────┘  └──────────┘      │
│                                    │
└─────────────┬──────────────────────┘
              │
              ↓
┌────────────────────────────────────┐
│                                    │
│    Top-3 Most Relevant Chunks      │
│                                    │
└─────────────┬──────────────────────┘
              │
              ↓
┌────────────────────────────────────┐
│                                    │
│      Multi-LLM Generation          │
│                                    │
│  Claude  │  Gemini  │  OpenAI     │
│                                    │
└─────────────┬──────────────────────┘
              │
              ↓
┌────────────────────────────────────┐
│                                    │
│       Final Answer                 │
│   (Grounded in Context)            │
│                                    │
└────────────────────────────────────┘
```

---

## Color Schemes

### Professional Theme
```
Input:       #E3F2FD (Light Blue)
Processing:  #FFF9C4 (Light Yellow)
Storage:     #F3E5F5 (Light Purple)
LLM:         #FCE4EC (Light Pink)
Output:      #E8F5E9 (Light Green)
```

### Tech Theme
```
User:        #00D9FF (Cyan)
Embedding:   #7B68EE (Purple)
Search:      #FFB627 (Gold)
Generate:    #FF6B6B (Red)
Response:    #51CF66 (Green)
```

---

## Adding to README

Place the ASCII diagram in the Architecture section:

```markdown
## 🏗️ Architecture

Here's how the system works:

[ASCII DIAGRAM HERE]

### Key Components

1. **Document Processing**: PDF → Chunks → Embeddings
2. **Query Processing**: User query → Vector embedding
3. **Retrieval**: Cosine similarity search → Top-K chunks
4. **Generation**: Multi-LLM → Context-grounded answer
```

---

## Creating a Visual Diagram (Step-by-Step)

### Using Excalidraw

1. **Go to**: https://excalidraw.com/
2. **Create boxes** for each step:
   - User Query
   - Embedding
   - Vector Search
   - Retrieval
   - LLM Generation
   - Final Answer
3. **Connect with arrows**
4. **Add icons**: 📄 👤 🔍 🤖 ✅
5. **Color code** by function
6. **Export** as PNG (1200x800px)
7. **Save** to `assets/architecture.png`

### Using Draw.io

1. **Go to**: https://app.diagrams.net/
2. **Template**: Flowchart
3. **Add shapes**: Rectangles with rounded corners
4. **Connect**: Use arrow connectors
5. **Style**: 
   - Border: 2px
   - Shadow: Yes
   - Font: Inter or Helvetica
6. **Export**: PNG with transparent background

---

## Final File Structure

```
rag-case-study/
├── assets/
│   ├── architecture.png       # Main architecture diagram
│   ├── demo.png               # App screenshot
│   └── comparison.png         # LLM comparison
└── README.md                  # Uses ASCII + references PNGs
```

---

## README Integration

```markdown
## 🏗️ Architecture

![RAG Architecture](assets/architecture.png)

### System Flow

1. **Query Embedding**: Convert user question to 768-dim vector
2. **Similarity Search**: Find top-3 most relevant chunks
3. **Context Assembly**: Combine retrieved chunks with query
4. **LLM Generation**: Generate answer using Claude/Gemini/GPT
5. **Response**: Return context-grounded answer

[Detailed ASCII diagram here]
```

---

## Tips for Great Diagrams

1. **Keep it simple**: Don't overcomplicate
2. **Use consistent colors**: Same function = same color
3. **Add metrics**: "768-dim", "Top-3", "50 chunks"
4. **Show data flow**: Clear arrows
5. **Highlight uniqueness**: Multi-LLM support
6. **Make it scannable**: Clear hierarchy
7. **Professional fonts**: Inter, Helvetica, or Arial

---

## Quick Mermaid for README

Paste this directly in your README.md:

````markdown
## Architecture

```mermaid
flowchart TD
    A[👤 User Query] --> B[🔤 Embedding Generation]
    B --> C[🔍 Cosine Similarity Search]
    C --> D[📄 Top-3 Chunks]
    D --> E{🤖 Multi-LLM}
    
    E -->|Option 1| F1[Claude Sonnet]
    E -->|Option 2| F2[Gemini Flash]
    E -->|Option 3| F3[GPT-4o]
    
    F1 --> G[✅ Final Answer]
    F2 --> G
    F3 --> G
    
    H[(chunks.json)] -.->|50 chunks| C
    I[(embeddings.pkl)] -.->|768-dim| C
```
````

This will render directly on GitHub!
