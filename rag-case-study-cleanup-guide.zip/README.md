# Custom RAG Implementation

> A from-scratch Retrieval-Augmented Generation system with multi-LLM support. Built to deeply understand RAG fundamentals before using production frameworks.

[![Python](https://img.shields.io/badge/python-3.11+-blue.svg)](https://www.python.org/downloads/)
[![Streamlit](https://img.shields.io/badge/streamlit-1.28+-red.svg)](https://streamlit.io/)
[![License](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)

## 🎯 Overview

This project demonstrates a **custom RAG system built from scratch** to understand how Retrieval-Augmented Generation works at a fundamental level. Instead of using frameworks like LangChain, I implemented:

- ✅ Custom document chunking pipeline
- ✅ Embedding generation & storage
- ✅ In-memory vector search
- ✅ Multi-LLM integration (Claude, Gemini, GPT-4)
- ✅ Comparative evaluation framework

**Why build from scratch?** To gain deep understanding of RAG mechanics before moving to production systems.

## 📊 Results

| Metric | Score |
|--------|-------|
| **Retrieval Accuracy** | 77.9% |
| **Semantic Similarity** | 0.787 |
| **Overall Quality** | 0.647/1.0 |
| **Questions Tested** | 249 |
| **Complexity Levels** | Basic, Intermediate, Advanced |

Tested on Apple's organizational structure case study with 3 different LLMs.

## 🚀 Quick Start

### Prerequisites

- Python 3.11+
- API key from one of: [Claude](https://console.anthropic.com/), [Gemini](https://aistudio.google.com/), or [OpenAI](https://platform.openai.com/)

### Installation

```bash
# Clone repository
git clone https://github.com/sushiva/rag-case-study.git
cd rag-case-study

# Install dependencies
pip install -r requirements.txt

# Run application
streamlit run app.py
```

### Usage

1. **Select LLM Provider**: Choose Claude, Gemini, or OpenAI from sidebar
2. **Enter API Key**: Input your API key for the selected provider
3. **Ask Questions**: Query the Apple organizational case study
4. **Compare Models**: Switch providers to compare responses

Example questions:
- "Why did Steve Jobs implement functional organization?"
- "How does Apple's structure differ from traditional companies?"
- "What are the benefits of Apple's organizational model?"

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────┐
│                    User Query                            │
└─────────────────────┬───────────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────────┐
│              Query Embedding Generation                  │
│         (sentence-transformers/all-mpnet-base-v2)       │
└─────────────────────┬───────────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────────┐
│            Cosine Similarity Search                      │
│              (In-Memory Vector Store)                    │
│                  chunks.json (50)                        │
│               embeddings.pkl (768-dim)                   │
└─────────────────────┬───────────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────────┐
│               Top-K Retrieval (K=3)                      │
│            Most Relevant Document Chunks                 │
└─────────────────────┬───────────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────────┐
│              Context-Grounded Generation                 │
│  ┌─────────────┬─────────────┬─────────────┐           │
│  │   Claude    │   Gemini    │   OpenAI    │           │
│  │  Sonnet 4   │ 2.0 Flash   │   GPT-4o    │           │
│  └─────────────┴─────────────┴─────────────┘           │
└─────────────────────┬───────────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────────┐
│                  Final Answer                            │
│            (Grounded in Retrieved Context)               │
└─────────────────────────────────────────────────────────┘
```

### Key Design Decisions

**In-Memory Storage**
- Perfect for small datasets (~50 chunks)
- Fast retrieval (<100ms)
- No external dependencies
- Easy to understand and debug

**Custom Implementation**
- Full control over chunking strategy
- Deep understanding of embedding mechanics
- Transparent retrieval process
- Educational value

**Multi-LLM Support**
- Compare Claude, Gemini, and OpenAI
- Consistent interface across providers
- Understand LLM-specific strengths
- No framework lock-in

## 📁 Project Structure

```
rag-case-study/
├── app.py                      # Streamlit web interface
├── src/
│   ├── rag_system.py          # Core RAG implementation
│   └── rag_system_multimodel.py  # Multi-LLM provider support
├── data/
│   ├── chunks.json            # Document chunks (50 chunks)
│   └── embeddings.pkl         # Pre-computed embeddings (768-dim)
├── requirements.txt           # Python dependencies
├── README.md                  # This file
├── LICENSE                    # MIT License
└── .gitignore                # Git ignore rules
```

## 🛠️ Technical Implementation

### Document Processing

```python
# Chunking Strategy
- Chunk size: 500 tokens
- Overlap: 50 tokens
- Total chunks: ~50 from Apple case study
```

### Embedding & Retrieval

```python
# Embedding Model
Model: sentence-transformers/all-mpnet-base-v2
Dimensions: 768
Similarity: Cosine

# Retrieval
Method: Top-K similarity search
K: 3 most relevant chunks
Storage: In-memory (pickle)
```

### Generation

```python
# Supported LLMs
Claude:
  - claude-3-5-sonnet-20241022
  - claude-3-5-haiku-20241022
  - claude-3-opus-20250219

Gemini:
  - gemini-2.0-flash
  - gemini-1.5-pro

OpenAI:
  - gpt-4o
  - gpt-4-turbo
  - gpt-3.5-turbo
```

## 📈 Evaluation Methodology

### Retrieval Evaluation
- **249 auto-generated questions** across 3 complexity levels
- **Accuracy@3**: Measures if correct chunk in top-3 results
- **Mean Reciprocal Rank**: Average position of correct chunk

### Generation Quality (15 Expert Questions)
- **Semantic Similarity**: Cosine similarity to reference (0-1)
- **Relevance**: Answer addresses question (1-5)
- **Coherence**: Logical structure and flow (1-5)
- **Groundedness**: Answers grounded in context (1-5)

## 🎓 Key Learnings

### What Worked Well

1. **In-memory storage** is sufficient for datasets <10K chunks
2. **Chunking strategy** (500 tokens, 50 overlap) balanced context and precision
3. **Claude 3.5 Sonnet** performed best with retrieval context
4. **Custom implementation** provided invaluable learning experience

### Limitations Identified

1. **Scalability**: Can't handle >10K chunks (RAM constraint)
2. **Persistence**: No data between sessions
3. **Single document**: Hard to add new documents
4. **Deployment**: Not production-ready

### Evolution to Production

These learnings led to building [RAG v3](https://github.com/sushiva/rag-casestudy-v3):
- ✅ Pinecone serverless vector database (scales to millions)
- ✅ LangChain framework for production patterns
- ✅ DigitalOcean deployment (24/7 availability)
- ✅ Multi-document support

## 🔑 Getting API Keys

### Claude (Anthropic) - Recommended
1. Visit [console.anthropic.com](https://console.anthropic.com/)
2. Sign up (free tier available)
3. Create API key
4. Free credits for testing

### Gemini (Google)
1. Visit [aistudio.google.com](https://aistudio.google.com/)
2. Sign in with Google account
3. Get API key
4. Generous free tier

### OpenAI
1. Visit [platform.openai.com](https://platform.openai.com/)
2. Create account
3. Add payment method (required)
4. Generate API key
5. Pay-as-you-go pricing

## 🚀 Deployment

### Local Development

```bash
streamlit run app.py
```

### Streamlit Cloud (Free)

1. Push code to GitHub
2. Go to [streamlit.io/cloud](https://streamlit.io/cloud)
3. Connect repository
4. Deploy (automatic!)

### Environment Variables

For production, use secrets management:

```toml
# .streamlit/secrets.toml
ANTHROPIC_API_KEY = "your-key"
GOOGLE_API_KEY = "your-key"
OPENAI_API_KEY = "your-key"
```

## 📊 Performance

| Operation | Time | Notes |
|-----------|------|-------|
| Query embedding | ~50ms | CPU-based |
| Similarity search | ~10ms | In-memory, 50 vectors |
| LLM generation | ~2-5s | Varies by provider |
| **Total response** | **~3-6s** | End-to-end |

Tested on: MacBook Pro M1, 16GB RAM

## 🤝 Contributing

This is an educational project, but suggestions welcome!

1. Fork the repository
2. Create feature branch (`git checkout -b feature/improvement`)
3. Commit changes (`git commit -m 'Add improvement'`)
4. Push to branch (`git push origin feature/improvement`)
5. Open Pull Request

## 📝 License

MIT License - see [LICENSE](LICENSE) file for details.

Free to use for learning, portfolio projects, and commercial applications.

## 👨‍💻 Author

**Sudhir Shivaram** - Machine Learning Engineer

- 🌐 Portfolio: [sushiva.github.io](https://sushiva.github.io)
- 📝 Blog: [Technical Deep-Dives](https://sushiva.github.io/sudhir-tech-blog)
- 💼 LinkedIn: [Connect with me](https://linkedin.com/in/yourprofile)
- 📧 Email: your.email@example.com

## 🔗 Related Projects

- [Healthcare RAG v3](https://github.com/sushiva/rag-casestudy-v3) - Production RAG with Pinecone & LangChain
- [Blog Article](https://sushiva.github.io/sudhir-tech-blog/) - Deep-dive into RAG architecture evolution

## 📚 Resources & References

- [RAG Paper](https://arxiv.org/abs/2005.11401) - Original RAG research
- [Sentence Transformers](https://www.sbert.net/) - Embedding models
- [LangChain Docs](https://python.langchain.com/) - Production RAG framework
- [HBR Case Study](https://hbr.org/2020/11/how-apple-is-organized-for-innovation) - Apple organizational model

## ⭐ Star History

If this project helped you understand RAG systems, please star it on GitHub!

[![Star History Chart](https://api.star-history.com/svg?repos=sushiva/rag-case-study&type=Date)](https://star-history.com/#sushiva/rag-case-study&Date)

## 📞 Questions?

- Open an [Issue](https://github.com/sushiva/rag-case-study/issues)
- Read the [blog article](https://sushiva.github.io/sudhir-tech-blog/)
- Connect on [LinkedIn](https://linkedin.com/in/yourprofile)

---

**Built with ❤️ for learning and education**

*Last updated: November 2024*
